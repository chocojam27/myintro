@extends('frontend.templates.layouts.default')
@section('content')
       <!-- Profile Start -->
       <section class="section bg-half">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="p-4 bg-white rounded shadow" style="z-index: 1;">
                            <div class="row align-items-center">
                                <div class="col-lg-2 col-md-3 text-md-left text-center">
                                    <img src="{{isset($user)?asset('uploads/avatar/'.$user->user_id.'/'.$user->image):asset('frontend/img/templates/jhon.jpg')}}" class="avatar avatar-large rounded-pill shadow d-block mx-auto" alt="">
                                </div><!--end col-->

                                <div class="col-lg-10 col-md-9">
                                    <div class="row align-items-center">
                                        <div class="col-md-7 text-md-left text-center mt-4 mt-sm-0">
                                            <h3 class="title mb-0">{{isset($user)?$user->fullname:'John Doe'}}</h3>
                                            <small class="text-muted h6 mr-2">{{isset($user)?$user->title:'creative director'}}</small>
                                            <ul class="list-unstyled social-icon mb-0 mt-2">
                                                @if (isset($user))
                                                @foreach ($user->social_url as $key => $url)
                                                <li class="list-inline-item"><a href="{{Str::contains($url, 'http')?$url:'https://'.$url}}" class="rounded" target="_blank"> <i class="mdi mdi-{{strtolower($user->social_provider[$key])}}" title="{{$user->social_provider[$key]}}"></i> </a></li>
                                                @endforeach
                                                @else
                                                <li class="list-inline-item"><a href="javascript:void(0)" class="rounded"><i class="mdi mdi-facebook" title="Facebook"></i></a></li>
                                                <li class="list-inline-item"><a href="javascript:void(0)" class="rounded"><i class="mdi mdi-instagram" title="Instagram"></i></a></li>
                                                <li class="list-inline-item"><a href="javascript:void(0)" class="rounded"><i class="mdi mdi-twitter" title="Twitter"></i></a></li>
                                                <li class="list-inline-item"><a href="javascript:void(0)" class="rounded"><i class="mdi mdi-google-plus" title="Google +"></i></a></li>
                                                <li class="list-inline-item"><a href="javascript:void(0)" class="rounded"><i class="mdi mdi-linkedin" title="Linkedin"></i></a></li>
                                                <li class="list-inline-item"><a href="javascript:void(0)" class="rounded"><i class="mdi mdi-dribbble" title="Dribbble"></i></a></li>
                                                @endif
                                            </ul><!--end icon-->
                                        </div><!--end col-->
                                        <div class="col-md-5 text-md-right text-center">
                                            <ul class="list-unstyled mb-0 mt-4">
                                                <li class="list-inline-item"><a href="page-blog.html" class="btn btn-primary"><i class="mdi mdi-email"></i> Contact Me</a></li>
                                                <li class="list-inline-item"><a href="page-profile-edit.html" class="btn btn-secondary" title="Edit Profile"><i class="mdi mdi-tools text-light"></i> Settings</a></li>
                                            </ul><!--end icon-->
                                        </div><!--end col-->
                                    </div><!--end row-->
                                </div><!--end col-->
                            </div><!--end row-->
                        </div>
                    </div><!--end col-->
                </div><!--end row-->

                <div class="row mt-4 pt-2">
                    <div class="col-md-6 col-12">
                        <div class="p-4 bg-white rounded shadow">
                            <h5>About Me</h5>
                            <div class="pb-4">
                                    @if (isset($user))
                                    <p class="text-muted mb-0">{!! $user->bio !!}</p>
                                    @else
                                <p class="text-muted mb-0">I have started my career as a trainee and prove my self and achieve all the milestone with good guidance and reach up to the project manager. In this journey, I understand all the procedure which make me a good developer, team leader, and a project manager.
                                <br><br>
                                Atque vero earum enim, dolore quis quos repellat alias harum quas dolorem debitis rerum soluta ab, animi illo veritatis optio fugit consequatur, facere totam placeat. Cumque distinctio magni excepturi sed culpa hic qui repellat vitae, laboriosam ullam accusamus ab illum quo earum quae eaque? Excepturi quas possimus eos ad molestias.
                                <br><br>
                                Atque vero earum enim, dolore quis quos repellat alias harum quas dolorem debitis rerum soluta ab, animi illo veritatis optio fugit consequatur, facere totam placeat. Cumque distinctio magni excepturi sed culpa hic qui repellat vitae, laboriosam ullam accusamus ab illum quo earum quae eaque? Excepturi quas possimus eos ad molestias.</p>
                                @endif
                            </div>
                        </div>
                    </div><!--end col-->

                    <div class="col-md-6 col-12 mt-4 mt-sm-0 pt-2 pt-sm-0">
                        <div class="p-4 bg-white rounded shadow">
                            <h5 class="pb-0 mb-0">Videos :</h5>

                            @if (Request::route()->getName() == 'profile.page' && (isset($user) && $user->user->pro == 1) || Request::route()->getName() == 'load.template')
                            <div class="row">
                                <div class="col-md-6 col-12 mt-4 pt-2">

                                    <div class="position-relative">
                                            @if (isset($user) && $user->user->pro == 1)
                                            <div class="play-icon">
                                                    <iframe src="https://player.vimeo.com/video/294281154?title=0&byline=0&portrait=0&transparent=0" class="play-btn video-play-icon" frameborder="0" allow="autoplay; encrypted-media" webkitallowfullscreen mozallowfullscreen allowfullscreen data-ready="true"><i class="mdi mdi-play text-primary rounded-pill bg-white shadow"></i></iframe>
                                                </div>
                                                @else
                                            <img src="images/about.jpg" class="rounded img-fluid mx-auto d-block" alt="">
                                            @endif
                                    </div>
                                </div><!--end col-->


                                <div class="col-md-6 col-12 mt-4 pt-2">
                                    <div class="position-relative">
                                            @if (isset($user) && $user->user->pro == 1)
                                            <div class="play-icon">
                                                    <iframe src="https://player.vimeo.com/video/294281154?title=0&byline=0&portrait=0&transparent=0" class="play-btn video-play-icon" frameborder="0" allow="autoplay; encrypted-media" webkitallowfullscreen mozallowfullscreen allowfullscreen data-ready="true"><i class="mdi mdi-play text-primary rounded-pill bg-white shadow"></i></iframe>
                                                </div>
                                                @else
                                            <img src="images/about.jpg" class="rounded img-fluid mx-auto d-block" alt="">
                                            @endif
                                    </div>
                                </div><!--end col-->

                                <div class="col-md-6 col-12 mt-4 pt-2">
                                    <div class="position-relative">
                                            @if (isset($user) && $user->user->pro == 1)
                                            <div class="play-icon">
                                                    <iframe src="https://player.vimeo.com/video/294281154?title=0&byline=0&portrait=0&transparent=0" class="play-btn video-play-icon" frameborder="0" allow="autoplay; encrypted-media" webkitallowfullscreen mozallowfullscreen allowfullscreen data-ready="true"><i class="mdi mdi-play text-primary rounded-pill bg-white shadow"></i></iframe>
                                                </div>
                                                @else
                                            <img src="images/about.jpg" class="rounded img-fluid mx-auto d-block" alt="">
                                            @endif
                                    </div>
                                </div><!--end col-->

                                <div class="col-md-6 col-12 mt-4 pt-2">
                                    <div class="position-relative">
                                            @if (isset($user) && $user->user->pro == 1)
                                            <div class="play-icon">
                                                    <iframe src="https://player.vimeo.com/video/294281154?title=0&byline=0&portrait=0&transparent=0" class="play-btn video-play-icon" frameborder="0" allow="autoplay; encrypted-media" webkitallowfullscreen mozallowfullscreen allowfullscreen data-ready="true"><i class="mdi mdi-play text-primary rounded-pill bg-white shadow"></i></iframe>
                                                </div>
                                                @else
                                            <img src="images/about.jpg" class="rounded img-fluid mx-auto d-block" alt="">
                                            @endif
                                    </div>
                                </div><!--end col-->

                            </div><!--end row-->
                            @endif
                        </div>
                    </div><!--end col-->
                </div><!--end row-->
            </div><!--end container-->
        </section><!--end section-->
        <!-- Profile End -->

@endsection


