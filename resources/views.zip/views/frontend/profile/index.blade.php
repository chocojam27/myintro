@extends('layouts.defaultprof')
@section('title','Profile')
@section('css')
<style>
    .section-create-page-tab .container .tab-content .tab-pane .thirdPage .GenerateForm select.form-control {
        min-width: 320px;
    }
    .section-create-page-tab .container .tab-content .tab-pane .secondPage {
        width: 80%;
    }
    .editTemplateTab{
        width: 80%;
        margin: 0 auto;
        padding: 50px 0px;
    }
    .section-create-page-tab .container .tab-content .tab-pane .thirdPage {
        max-width: 90%;
    }
    .ckeditor-container {
        width: 80%;
        margin: 0 auto;
        margin-bottom: 30px;
    }
    .saveGenerate {
        cursor: pointer;
    }
    span.hint {
        position: absolute;
        font-family: Montserrat-Regular;
        color: #9a9a9a;
        top: 10px;
        left: 18px;
        font-size: 25px;
    }
    .hint-pl {
        padding-left: 194px!important;
    }
    .btn-placeholder {
        cursor: pointer;
    }
    #profileBio textarea {
        resize:vertical;
        min-height:200px;
    }
    .item-theme.active > div{
        background: #c046e399;
        border-radius: 5px;
    }
    .item-theme i {
        display: none;
    }
    .item-theme.active i {
        display: inline-block;
        font-size: 100px;
        color: #fff;
    }
    .item-theme iframe {
        position: absolute;
        top: -340px;
        left: -469px;
        width: calc(100% * 4.5);
        height: calc(100% * 4.5);
        transform: scale(0.22);
    }
    .upload-pic .profile.error {
        -webkit-box-shadow: 0 0 4px 1px red;
        box-shadow: 0 0 4px 1px red;
        border-radius: 5px;
    }
    .upload-pic .profile.error .invalid-feedback,
    #template.error .invalid-feedback,
    #socials.error .invalid-feedback {
        display: block;
        padding-top: 10px;
    }
    .section-create-page-tab .container .tab-content .tab-pane .placeholder .phForm form input.form-control,
    .section-create-page-tab .container .tab-content .tab-pane .phForm .form-inline select.form-control {
        height: 65px;
    }
    .section-create-page-tab .container .tab-content .tab-pane .phForm .form-inline select.form-control {
        width: 25%;
        border-radius: 20px;
        font-family: Montserrat-Medium;
        margin: 10px;
        padding: 20px;
    }
    #appendHere .form-inline {
        padding: 10px 0;
    }
    .placeholder .saver input[type=submit] {
        width: 295px!important;
        font-size: 18px;
        font-family: Montserrat-Medium;
        background-color: #53ba58;
        color: #fff;
        padding: 16px 20px;
        margin: 0 auto;
        border-radius: 20px;
        cursor: pointer;
    }
    .tab-pane .stats{
        width: 90%;
        margin: 0 auto;
    }
    .tab-pane .stats .tableHolder{
        padding: 20px 0px;
    }
    .tab-pane .stats .statBtn div{
       border: 1px solid #c046e3;
       padding: 10px 20px;
       border-radius: 10px;
    }
    .tab-pane .stats .statBtn div p{
       margin: 0px;
       color: #c046e3;
       font-family: 'Montserrat-Bold';
       font-size: 16px;
    }
    .tab-pane .stats .statBtn div p span{
       margin: 0px;
       color: #c046e3;
       font-family: 'Montserrat-Regular';
    }
    .tab-pane .stats .statBtn div p.title{
       margin: 0px;
       color: #c046e3;
       font-size: 20px;
    }
    .tab-pane .stats .statBtn.active div p,.tab-pane .stats .statBtn.active div p span,.tab-pane .stats .statBtn.active div p.title{
       color: #fff;
    }
    .tab-pane .stats .statBtn.active div{
       background-color: #c046e3;
       color: #fff;
       border: 1px solid transparent;
    }
    @media (max-width: 1650px) {
        .hint-pl {
            padding-left: 140px!important;
        }
        span.hint {
            top: 6px;
            left: 13px;
            font-size: 18px;
        }
    }
    @media (min-width: 1920px) {
        .item-theme iframe {
            top: -265px;
            left: -395px;
            width: calc(100% * 3.33);
            height: calc(100% * 3);
            transform: scale(0.3);
        }
    }
</style>
@stop
@section('content')
<main role="main" class="contents contact-page">
    <section class="section-create-page-tab">
        <div class="container">
            <div id="exTab1">
                <ul  class="nav nav-pills">
                    @if ($profile)
                    <li>
                        <a class="nav-a active show" href="#1a" data-toggle="tab">Templates</a>
                    </li>
                    @endif
                    <li>
                        <a class="nav-a {{$profile?'':'active show'}}" href="#2a" data-toggle="tab">Profile Page</a>
                    </li>
                    <li>
                        <a class="nav-a" href="#3a" data-toggle="tab">Placeholder</a>
                    </li>
                    <li>
                        <a class="nav-a" href="#4a" data-toggle="tab">Statistics</a>
                    </li>
                    @if ($profile)
                    <li>
                        <a class="nav-a" href="{{route('profile.page', $profile->url)}}" target="_blank">MyIntro.Page</a>
                    </li>
                    @endif
                </ul>
                <div class="tab-content clearfix">
                    {{-- templates tab --}}
                    <form class="tab-pane {{$profile?'active':''}}" id="1a" enctype="multipart/form-data">
                        <input type="hidden" name="profileID" value="{{$profile->id??''}}">
                        <div class="firstPage oneApages">
                            <div class="text-center py-3 d-block border-bottom"><h2>Page Templates</h2></div>
                            <div class="table-responsive py-3">
                                <table class="table table-striped DataTableID" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>Date</th>
                                            <th>Name of the template</th>
                                            <th>Tag</th>
                                            <th>Name</th>
                                            <th>Statistics</th>
                                            <th>Action</th>
                                            <th>Generate URL</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @if($page_templates)
                                            @foreach ($page_templates as $pages)
                                            <tr>
                                                <td>{{$pages->created_at}}</td>
                                                <td>{{$pages->page_template_name}}</td>
                                                <td>{{$pages->tag}}</td>
                                                <td>{{$pages->full_name}}</td>
                                                <td><a href="" title="View URLs" class="statsView " data-pageid="{{$pages->id}}">{{$user_subs->subscription->invoice??''?'URL: '.$pages->url->count():'URL: '.$pages->url->count().' '.'of 30'}}</a></td>
                                                <td>
                                                    <ul class="list-inline">
                                                        <li class="list-inline-item mx-0 mb-1">
                                                            <a href="" class="pagesStep btn btn-primary text-white" data-step="1" data-pageid="{{$pages->id}}" title="edit"><i class="fa fa-pencil" aria-hidden="true" ></i></a>
                                                        </li>
                                                        <li class="list-inline-item">
                                                            <a data-id="{{$pages->id}}" class="deletePageTemplate btn btn-danger" href="" title="delete"><i class="fa fa-trash" aria-hidden="true"></i></a>
                                                        </li>
                                                    </ul>
                                                </td>
                                                {{-- <td><a title="Generate New URL" class="copyOnTable btn btn-success" data-url="{{$profile->url.'/'.$pages->url}}" href="">Generate</a></td> --}}
                                                <td><a title="Generate New URL" class="btn btn-success text-white pagesStep" data-generate="true" data-pageid="{{$pages->id}}" href="">Generate</a></td>
                                            </tr>
                                            @endforeach
                                        @endif
                                    </tbody>
                                </table>
                            </div>
                            <a href="#" class="text-center btn-create-page position-relative btn-block my-2"><img src="{{asset('frontend')}}/img/create-icon.png">Create new page</a>
                        </div>
                        <div class="secondPage oneApages">
                           @include('frontend.includes.secondPage')
                        </div>
                        <div class="thirdPage oneApages">
                            @include('frontend.includes.thirdPage')
                        </div>
                    </form>
                    {{-- profile tab --}}
                    <form class="tab-pane {{$profile?'':'active'}}" id="2a" enctype="multipart/form-data">
                        @if (isset($profile) && $profile)
                            <input type="hidden" name="id" value="{{$profile->id}}">
                        @endif
                        <input type="hidden"  name="user_id" value="{{Auth::user()->id}}">
                        <ul class="li-progress-bar list-unstyled text-center">
                            <li class="pb-item-1 pb-item default"><span><p>1</p></span></li>
                            <li class="pb-item-2 pb-item"><span><p>2</p></span></li>
                            <li class="pb-item-3 pb-item"><span><p>3</p></span></li>
                            <li class="pb-item-4 pb-item"><span><p>4</p></span></li>
                            <li class="pb-item-5 pb-item"><span><p>5</p></span></li>
                        </ul>
                        <div class="upload-pic" id="step-1">
                            <div class="d-flex">
                                <div class="profile text-center">
                                    <img id="imageUpload" src="{{isset($profile)?asset('uploads/avatar/'.$profile->user_id.'/'.$profile->image):asset('frontend/img/default-profile.png')}}">
                                    <span class="invalid-feedback" role="alert">
                                        <strong>The image field is required.</strong>
                                    </span>
                                </div>
                                <div class="profile-title">
                                    <h2>Profile Picture</h2>
                                    <input type="file" name="image" class="image-upload" accept="image/*">
                                    <a href="" class="btn-upload-photo"><img src="{{asset('frontend')}}/img/add.png"> Upload Photo</a>
                                </div>
                            </div>
                            <div class="text-center" id="template">
                                <h2>Choose your design</h2>
                                <span class="invalid-feedback" role="alert">
                                    <strong>The template field is required.</strong>
                                </span>
                            </div>
                            <div class="owl-theme owl-carousel owl-profile-theme">
                                <div class="item">
                                    <div class="item-theme relative {{isset($profile) && $profile->template == 'free-1'?'active':''}}">
                                        <div style="position:absolute; height:100%; width:100%; top:0; left:0; z-index: 99">
                                            <i class="fa fa-check center-div"></i>
                                        </div>
                                        <input type="radio" name="template" value="free-1" style="display:none">
                                        <iframe src="{{route('load.template', 'free-1').'?iframe=true'}}" height="100%" width="100%" frameborder="0" scrolling="no"></iframe>
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="item-theme relative {{isset($profile) && $profile->template == 'free-2'?'active':''}}">
                                        <div style="position:absolute; height:100%; width:100%; top:0; left:0; z-index: 99">
                                            <i class="fa fa-check center-div"></i>
                                        </div>
                                        <input type="radio" name="template" value="free-2" style="display:none">
                                        <iframe src="{{route('load.template', 'free-2').'?iframe=true'}}" height="100%" width="100%" frameborder="0" scrolling="no"></iframe>
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="item-theme relative {{isset($profile) && $profile->template == 'free-3'?'active':''}}">
                                        <div style="position:absolute; height:100%; width:100%; top:0; left:0; z-index: 99">
                                            <i class="fa fa-check center-div"></i>
                                        </div>
                                        <input type="radio" name="template" value="free-3" style="display:none">
                                        <iframe src="{{route('load.template', 'free-3').'?iframe=true'}}" height="100%" width="100%" frameborder="0" scrolling="no"></iframe>
                                    </div>
                                </div>
                            </div>
                            <div class="nxt-con text-right">
                                <a href="#" class="next-1 next">Next</a>
                            </div>
                        </div>
                        <div class="upload-pic" id="step-2">
                            <div class="text-center">
                                <h2>Profile</h2>
                            </div>
                            <div class="profile-form">
                                <div class="form-group">
                                    <input type="text" class="form-control" placeholder="Fullname" name="fullname" value="{{isset($profile)?$profile->fullname:''}}">
                                    <span class="invalid-feedback" role="alert" style="margin-left: 10px;">
                                        <strong></strong>
                                    </span>
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control" placeholder="Title" name="title" value="{{isset($profile)?$profile->title:''}}">
                                    <span class="invalid-feedback" role="alert" style="margin-left: 10px;">
                                        <strong></strong>
                                    </span>
                                </div>
                                <div class="form-group">
                                    <textarea id="profileBio" class="form-control" placeholder="Bio" rows="5" name="bio">{{isset($profile)?$profile->bio:''}}</textarea>
                                    <span class="invalid-feedback" role="alert" style="margin-left: 10px;">
                                        <strong></strong>
                                    </span>
                                </div>
                            </div>
                            <div class="nxt-con text-right">
                                <a href="#" class="prev-1 next">Previous</a>
                                <a href="#" class="next-2 next">Next</a>
                            </div>
                        </div>
                        <div class="upload-pic" id="step-3">
                            <div class="text-center" id="socials">
                                <h2>Social Sites</h2>
                                <span class="invalid-feedback" role="alert">
                                    <strong></strong>
                                </span>
                            </div>
                            <div class="profile-form" id="appendSocial">
                                <div class="switcher">
                                    <div class="form-inline">
                                        <h5>Add Extra URLs</h5>
                                        <label class="switch {{$user_subs->subscription->subscription_type == 1?'':'pro'}}">
                                            <input type="checkbox" name="add_extra_url" {{isset($profile) && $profile->add_extra_url == 'true'?'checked':''}} value="true">
                                            <span style="{{ $user_subs->subscription->subscription_type == 1?'':'cursor: not-allowed'}}" class="slider round" data-toggle="tooltip" data-placement="bottom" title="this will activate custom place holder, it will look like thing below"></span>
                                        </label>
                                    </div>
                                </div>
                                @php
                                    $socialArray = ['Facebook','Twitter','Instagram','LinkedIn','YouTube'];
                                @endphp
                                @if ($profile)
                                    @foreach ($profile->social_url as $key => $url)
                                    <div class="form-inline">
                                        <select disabled name="social_provider" class="form-control">
                                            @foreach ($socialArray as $k => $social_item)
                                                @if ($profile->social_provider[$key] == $social_item)
                                                <option value="{{$social_item}}" selected>{{$social_item}}</option>
                                                @php
                                                    unset($socialArray[$k]);
                                                @endphp
                                                @else
                                                <option value="{{$social_item}}">{{$social_item}}</option>
                                                @endif
                                            @endforeach
                                        </select>
                                        <input type="text" class="form-control fullname" placeholder="example.com" name="social_url[]" value="{{$url}}">
                                        @if ($user_subs->subscription->subscription_type && $profile->add_extra_url)
                                            <a class="btn-remadd fc">-</a>
                                        @endif
                                    </div>
                                    @endforeach
                                @endif

                                @if (count($socialArray) && ($user_subs->subscription->subscription_type && $profile->add_extra_url))
                                <div class="form-inline">
                                    <select name="social_provider" class="form-control">
                                        @foreach ($socialArray as $item)
                                        <option value="{{$item}}">{{$item}}</option>
                                        @endforeach
                                    </select>
                                    <input type="text" class="form-control fullname" placeholder="example.com" name="social_url[]">
                                    <a class="btn-remadd">+</a>
                                </div>
                                @endif
                            </div>
                            <div class="nxt-con text-right">
                                <a href="#" class="prev-2 next">Previous</a>
                                <a href="#" class="next-3 next">Next</a>
                            </div>
                        </div>
                        <div class="upload-pic" id="step-4">
                            <div class="text-center">
                                <h2>Social Sites</h2>
                            </div>
                            <div class="profile-form">
                                <div class="switcher">
                                    <div class="form-inline">
                                        <h5>Activate Contact Form</h5>
                                        {{-- @dd($user_subs); --}}
                                        <label class="switch {{$user_subs->subscription->subscription_type == 1?'':'pro'}}">
                                            <input type="checkbox" name="add_contact" {{isset($profile) && $profile->add_contact == 'true'?'checked':''}} value="true">
                                            <span style="{{ $user_subs->subscription->subscription_type == 1?'':'cursor: not-allowed'}}" class="slider round" data-toggle="tooltip" data-placement="bottom" title="{{$user_subs->subscription->subscription_type == 1?'this will activate custom place holder, it will look like thing below':'Go Pro! to active this feature.'}}"></span>
                                        </label>
                                    </div>
                                    <div class="form-inline">
                                        <h5>Add Video to Your Page</h5>
                                        <label class="switch {{$user_subs->subscription->subscription_type == 1?'':'pro'}}">
                                            <input type="checkbox" name="add_video" {{isset($profile) && $profile->add_video == 'true'?'checked':''}} value="true">
                                            <span style="{{ $user_subs->subscription->subscription_type == 1?'':'cursor: not-allowed'}}" class="slider round" data-toggle="tooltip" data-placement="bottom" title="{{$user_subs->subscription->subscription_type == 1?'this will activate custom place holder, it will look like thing below':'Go Pro! to active this feature.'}}"></span>
                                        </label>
                                    </div>
                                    {{-- <div class="form-inline">
                                        <h5>Add Extra URLs</h5>
                                        <label class="switch">
                                            <input type="checkbox" name="add_extra_url" {{isset($profile) && $profile->add_extra_url == 'true'?'checked':''}} value="true">
                                            <span class="slider round" data-toggle="tooltip" data-placement="bottom" title="this will activate custom place holder, it will look like thing below"></span>
                                        </label>
                                    </div> --}}
                                </div>
                            </div>
                            <div class="nxt-con text-right">
                                <a href="#" class="prev-3 next">Previous</a>
                                <a href="#" class="next-4 next">Next</a>
                            </div>
                        </div>
                        <div class="upload-pic" id="step-5">
                            <div class="text-center">
                                <h2>URL</h2>
                            </div>
                            <div class="profile-form">
                                <div class="form-group relative">
                                    <span class="hint">myintro.page/</span>
                                    <input type="text" class="form-control hint-pl" data-domain="{{config('app.url')}}" name="url" value="{{isset($profile)?$profile->url:''}}">
                                    <span class="invalid-feedback" role="alert" style="margin-left: 10px;">
                                        <strong></strong>
                                    </span>
                                </div>
                                <div class="form-inline CopyBtnHolder" style="display:none">
                                    <a class="btnPink" href="#" id="btnCopy">Copy </a>
                                </div>
                            </div>
                            <div class="nxt-con text-right">
                                <a href="#" class="prev-4 next">Previous</a>
                                <a href="#" class="next-5 next">Submit</a>
                            </div>
                        </div>
                    </form>
                    {{-- placeholder tab --}}
                    <div class="tab-pane" id="3a">
                        <!-- marcov -->
                        <div class="placeholder">
                            <h3 class="phTitle">Placeholder</h3>
                            <div class="switcher row">
                                <h5 class="col-md-8">Activate custom Placeholder</h5>
                                <div class="col-md-4 text-right">
                                    <label class="switch" id="btn-custom-placeholder">
                                        <input type="checkbox" {{$user_subs->subscription->subscription_type?:'disabled'}} name="custom_placeholder" value="true">
                                        <span class="slider round" data-toggle="tooltip" data-placement="bottom"
                                        title="{{$user_subs->subscription->subscription_type?'This is a this will activate custom place holder, it will look like thing below':'This is a Pro Feature'}}"></span>
                                    </label>
                                </div>
                            </div>
                            <div class="phForm">
                                <form id="placeholder-form">
                                    <input type="hidden" name="placeholder_ids">
                                        @if ($profile_placeholders)
                                            <input type="hidden" name="profile_placeholder_id" value="{{$profile_placeholders->id}}">
                                            @php
                                                $phId = explode(',',$profile_placeholders->placeholder_IDs);
                                                $phVals = explode(',',$profile_placeholders->placeholder_contents);
                                            @endphp
                                            @foreach ($phVals as $key => $placeHolderVal)
                                            <div class="form-inline justify-content-center">
                                                <select disabled name="placeholder_id" class="form-control">
                                                    @foreach ($placeholders as $k => $placeholder)
                                                        @if ($phId[$key] == $placeholder->id)
                                                            <option value="{{$placeholder->id}}">{{$placeholder->format}}</option>
                                                        @php
                                                            unset($placeholders[$k]);
                                                        @endphp
                                                        @else
                                                            {{-- <option value="{{$placeholder->id}}">{{$placeholder->format}}</option> --}}
                                                        @endif
                                                    @endforeach
                                                </select>
                                                <input class="form-control" type="text" name="placeholder_value[]" placeholder="Type Here" value="{{$placeHolderVal}}">
                                                <a class="form-control btn-placeholder"><i class="fa fa-minus"></i></a>
                                            </div>
                                            @endforeach
                                        @endif
                                    <div class="form-inline justify-content-center">
                                        <select class="form-control" name="placeholder_id">
                                            @foreach ($placeholders as $placeholder)
                                                <option value="{{$placeholder->id}}">{{$placeholder->format}}</option>
                                            @endforeach
                                        </select>
                                        <input class="form-control" type="text" name="placeholder_value[]" placeholder="Type Here">
                                        <a class="form-control btn-placeholder"><i class="fa fa-plus"></i></a>
                                    </div>
                                </form>
                            </div>
                            <div class="phForm" style="display:none">
                                <h5>Custom Placeholder</h5>
                                <form id="other-placeholder-form">
                                    <div id="appendHere">
                                        <input type="hidden" name="placeholder_names">
                                        <input type="hidden" name="placeholder_formats">
                                        <span class="invalid-feedback" role="alert">
                                            <strong>The image field is required.</strong>
                                        </span>
                                        @if ($other_placeholders)
                                            <input type="hidden" name="other_placeholders_id" value="{{$other_placeholders->id}}">
                                            @php
                                                $oPhFormat = explode(',',$other_placeholders->format);
                                                $oPhdesc = explode(',',$other_placeholders->description);
                                            @endphp
                                            @foreach ($oPhdesc as $key => $desc)
                                            <div class="form-inline justify-content-center">
                                                <input disabled class="form-control" type="text" name="placeholder_name" value="{{$desc}}">
                                                <input disabled class="form-control" type="text" name="placeholder_format" value="{{$oPhFormat[$key]}}">
                                                <a class="form-control btn-placeholder"><i class="fa fa-minus"></i></a>
                                            </div>
                                            @endforeach
                                        @endif
                                        <div class="form-inline justify-content-center">
                                            <input class="form-control" type="text" name="placeholder_name" placeholder="Name of the Placeholder">
                                            <input class="form-control" type="text" name="placeholder_format" placeholder="%Example%">
                                            <a class="form-control btn-placeholder"><i class="fa fa-plus"></i></a>
                                        </div>
                                    </div>
                                </form>
                            </div>
                            <div class="saver">
                                <input type="submit" class="form-control saveBtn" value="Save">
                            </div>
                        </div>
                    </div>
                    {{-- statistics tab --}}
                    <div class="tab-pane" id="4a">
                        <ul class="nav nav-tabs" id="myTab" role="tablist">
                            <li class="nav-item">
                                <a class="nav-link active" id="profile-tab" data-toggle="tab" href="#profile" role="tab" aria-controls="profile" aria-selected="true">Profile Page</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" id="template-tab" data-toggle="tab" href="#templateTab" role="tab" aria-controls="template" aria-selected="false">Template Pages</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" id="url-tab" data-toggle="tab" href="#url" role="tab" aria-controls="url" aria-selected="false">Generated URLs</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" id="account-tab" data-toggle="tab" href="#account" role="tab" aria-controls="account" aria-selected="false">My Account</a>
                            </li>
                        </ul>
                        <div class="tab-content  border-0" id="myTabContent">
                            <div class="tab-pane fade show active" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                                <div class="table-responsive">
                                    {{-- <div class="titleHolder py-3">
                                        <h4>Profile Details:</h4>
                                    </div> --}}
                                    <ul class="list-unstyled">
                                        <li class="list-item">
                                            <p><b>Number of Views:</b></p>
                                            <ul class="list-group mb-3">
                                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                                    Total:
                                                    {{-- dd($profile->views->where('genPage_id',null)->get()->count()); --}}
                                                    <span class="badge badge-primary badge-pill">{{$profile->views->where('genPage_id',null)->count()}}</span>
                                                </li>
                                            </ul>
                                        </li>
                                        <li class="list-item">
                                            <p><b>Number of Clicks:</b></p>
                                            <ul class="list-group mb-3">
                                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                                    Social Sites:
                                                    <span class="badge badge-primary badge-pill">{{$profile->clicks->where('social',1)->count()}}</span>
                                                </li>
                                                {{-- <li class="list-group-item d-flex justify-content-between align-items-center">
                                                    URLs:
                                                    <span class="badge badge-primary badge-pill">{{$profile->clicks->where('url',1)->count()}}</span>
                                                </li> --}}
                                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                                    Contact Form:
                                                    <span class="badge badge-primary badge-pill">{{$profile->clicks->where('contact',1)->count()}}</span>
                                                </li>
                                            </ul>
                                        </li>
                                        <li class="list-item">
                                            <p><b>Number of Emails Received: </b></p>
                                            <ul class="list-group mb-3">
                                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                                    Total:
                                                    <span class="badge badge-primary badge-pill">{{$profile->email_count}}</span>
                                                </li>
                                            </ul>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="templateTab" role="tabpanel" aria-labelledby="template-tab">
                                <div class="table-responsive">
                                    <table class="table table-striped DataTableID"  width="100%" cellspacing="0">
                                        <thead>
                                            <tr>
                                                {!!$user_subs->subscription->subscription_type?'<th>Date</th>':''!!}
                                                <th>Template Name</th>
                                                <th>Number Active Of URLs </th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @forelse($page_templates as $pages)
                                                <tr>
                                                    @if ($user_subs->subscription->subscription_type)
                                                        <td>{{$pages->created_at}}</td>
                                                    @endif
                                                    <td>{{$pages->page_template_name}}</td>
                                                    <td>{{$pages->url->count()}}</td>
                                                    <td><a href="" title="View URLs" class="statsView btn btn-primary" data-pageid="{{$pages->id}}"><i class="fa fa-eye" aria-hidden="true"></i></a> | <a data-id="{{$pages->id}}" class="deletePageTemplate btn btn-danger" href="" title="delete"><i class="fa fa-trash" aria-hidden="true"></i></a></td>
                                                </tr>
                                            @empty
                                            @endforelse
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="url" role="tabpanel" aria-labelledby="url-tab">
                                <div class="table-responsive">
                                    <table class="table table-striped DataTableID"  width="100%" cellspacing="0">
                                        <thead>
                                            <tr>
                                                {!!$user_subs->subscription->subscription_type?'<th>Date</th>':''!!}
                                                <th>Page Name</th>
                                                <th>Clicks</th>
                                                <th>Page Views</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @forelse ($genURL as $url)
                                                <tr>
                                                    @if ($user_subs->subscription->subscription_type)
                                                        <td>{{$url->created_at}}</td>
                                                    @endif
                                                    <td>{{$url->name}}</td>
                                                    <td>{{$url->clicks->count()}}</td>
                                                    <td>{{$url->views->count()}}</td>
                                                    <td>
                                                        <ul class="list-inline">
                                                            {{-- <li class="list-inline-item">
                                                                <a target="_blank" class="btn btn-primary pagesStep" data-urlid="{{$url->id}}" data-step="2" href="#" title="Edit Placeholders">
                                                                    <i class="fa fa-pencil" aria-hidden="true"></i>
                                                                </a>
                                                            </li> --}}
                                                            <li class="list-inline-item">
                                                                <a target="_blank" class="btn btn-primary" href="{{route('inner.page',['id' => $profile->url, 'innerId' => $url->url])}}" title="View">
                                                                    <i class="fa fa-eye" aria-hidden="true"></i>
                                                                </a>
                                                            </li>
                                                            <li class="list-inline-item">
                                                                <a class="copyOnTable btn btn-primary" data-url="{{$profile->url.'/'.$url->url}}" href="" title="Copy to Clipboard">
                                                                    <i class="fa fa-clipboard" aria-hidden="true"></i>
                                                                </a>
                                                            </li>
                                                            <li class="list-inline-item">
                                                                <a class="btn btn-danger deleteGen" data-genid="{{$url->id}}" href="#" title="Delete">
                                                                    <i class="fa fa-trash-o" aria-hidden="true"></i>
                                                                </a>
                                                            </li>
                                                        </ul>
                                                    </td>
                                                </tr>
                                            @empty
                                            @endforelse
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="account" role="tabpanel" aria-labelledby="account-tab">
                                <div class="row no-gutters">
                                    <div class="col-md-6 p-3">
                                        <div class="titleHolder py-3">
                                            <h4>Credentials:</h4>
                                        </div>
                                        <form  id="updateUser">
                                            <div class="form-group">
                                                <label for="">Email:</label>
                                                <input type="text" name="email" class="form-control" placeholder="john@doe.com" value="{{Auth::user()->email}}">
                                            </div>
                                            <div class="form-group">
                                                <label for="">New Password:</label>
                                                <input type="password" name="newPassword" class="form-control" placeholder="**********">
                                            </div>
                                            <div class="form-group">
                                                <label for="">Confirm Password:</label>
                                                <input type="password" name="conPassword" class="form-control" placeholder="**********">
                                            </div>
                                            <input type="submit" class="btn btn-block btn-primary" value="Update">
                                        </form>
                                    </div>
                                    <div class="col-md-6 p-3">
                                        <div class="titleHolder py-3">
                                            <h4>Subscription Details:</h4>
                                        </div>
                                        <ul class="list-unstyled">
                                            <li class="list-item">
                                                <p>Subscription type: <b>{{$user_subs->subscription->subscription_type?'Pro ':'Free '}}</b></p>
                                            </li>
                                            <li class="list-item">
                                                <p>Amount: <b>{{$user_subs->subscription->invoice->price??'Free'}}</b></p>
                                            </li>
                                            <li class="list-item">
                                                <p>Start Date: <b>{{$user_subs->subscription->invoice?$user_subs->subscription->start_date:$user_subs->subscription->created_at}}</b></p>
                                            </li>
                                            <li class="list-item">
                                                <p>Invoice Number: <b>{{$user_subs->subscription->invoice->transaction_id??'None'}}</b></p>
                                            </li>
                                            <li class="list-item">
                                                <p>Profile Number: <b>{{$user_subs->subscription->invoice->recurring_id??'None'}}</b></p>
                                            </li>
                                            <li class="list-item">
                                                <a class="btn btn-info btn-block mb-3 checkInvoice " href="">See More</a>
                                            </li>

                                            {{-- @dd($user_subs->subscription->invoice); --}}
                                            @if ($user_subs->subscription->subscription_type)
                                                <li class="list-item">
                                                    <div class="alert alert-info" role="alert">
                                                        You can cancel your subscription in your account on Paypal. <a target="_blank" href="https://www.paypal.com/" class="alert-link">Go to Paypal</a> or see <a target="_blank" class="alert-link" href="https://www.paypal.com/ph/smarthelp/article/how-do-i-cancel-a-recurring-payment,-subscription,-or-automatic-billing-agreement-i-have-with-a-merchant-faq1067">Instructions from Paypal.</a>
                                                    </div>
                                                </li>
                                            @else
                                                <li class="list-item">
                                                    <a href="{{ route('paypal.express-checkout', ['recurring' => true]) }}" class="btn btn-pink btn-block">Go Pro Now</a>
                                                </li>
                                            @endif
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="footer-bg no-content bg-common" style="background-image: url('{{asset('frontend')}}/img/footer.png');">
        <div class="container">

        </div>
    </section>
    <div id="statsModal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="statsModalTitle" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="statsModalTitle">URL STATISTICS:</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body" id="appendUrlModal">

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
    <div id="paypalModal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="paypalModalTitle" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="paypalModalTitle">Subscription Details:</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body" id="appendPaypalModal">

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
    <div id="invoiceModal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="invoiceModalTitle" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered" style="min-width: 90% ">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="invoiceModalTitle">Subscription Details:</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body" id="appendInvoiceModal">

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade upgraderModal" tabindex="-1" role="dialog" aria-labelledby="upgraderModal" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content">
                <section class="section-planspricing" style="background-image: url('{{asset('frontend')}}/img/footer.png');">
                    <div class="container">
                        <h1 class="text-center text-capitalize pt-5" style="color:#c046e3">UPGRADE ACCOUNT</h1>
                            <ul class="list-unstyled">
                            <li>
                                <h4>Free</h4>
                                <h5>$0.00</h5>
                                <p>Lorem Ipsum</p>
                                <p>Lorem Ipsum</p>
                                <p>Lorem Ipsum</p>
                                @if($user_subs->subscription->subscription_type)
                                @else
                                <p>Your Current Plan</p>
                                @endif
                            </li>
                            <li>
                                <h4>Pro</h4>
                                <h5>$4.99</h5>
                                <p>Lorem Ipsum</p>
                                <p>Lorem Ipsum</p>
                                <p>Lorem Ipsum</p>
                                @if($user_subs->subscription->subscription_type)
                                    <p>Your Current Plan</p>
                                @else
                                <a href="{{ route('paypal.express-checkout', ['recurring' => true]) }}" class="btn goproBtn">Go Pro</a>
                                @endif
                                <p class="discover">DISCOVER ALL PRO FEATURES</p>
                            </li>
                        </ul>
                    </div>
                </section>
            </div>
        </div>
    </div>
</main>
@stop
@section('js')
<script type="text/javascript">
    var timer;
    $(window).on('load', function () {
        // initCKeditor();
        CKEDITOR.replaceAll('editEditor');
    });
    $(document).on('submit','#updateUser',function(e){
        e.preventDefault();
        var formData = new FormData(this);
        $.ajax({
            type: "post",
            url: "{{route('credential.update')}}",
            data: formData,
            dataType: "json",
            processData: false,
            contentType: false,
            success: function (response) {
                Swal.fire({
                    type: response.result[0]['type'],
                    title: response.result[0]['title'],
                    text: response.result[0]['message'],
                });
                location.reload();
            },error: function (errors) {
                $.each(errors.responseJSON.errors, function (indexInArray, valueOfElement) {
                    Swal.fire({
                        type: 'error',
                        title: 'error',
                        text: valueOfElement[0],
                    });
                });
            }
        });
    });
    $(document).on('click','.checkInvoice',function(e){
        e.preventDefault();
        $.ajax({
            type: "get",
            url: "{{route('paypal.getInvoice')}}",
            success: function (data) {
                if(data.result == 'success'){
                    $("#appendInvoiceModal").empty();
                    $('#appendInvoiceModal').append(data.html);
                    $('.DataTableID').DataTable();
                    $('#invoiceModal').modal('show');
                }else{
                    Swal.fire({
                        type: data.result,
                        title: data.title,
                        text: data.message,
                    });
                }
            },
        });
    });
    $(document).on('click','.checkPpalRec',function(e){
        e.preventDefault();
        rec_id = $(this).data('id');
        $('#invoiceModal').modal('hide');
        $.ajax({
            type: "get",
            url: "{{route('paypal.getProfile')}}",
            data: {id: rec_id},
            success: function (data) {
                if(data.result == 'success'){
                    $("#appendPaypalModal").empty();
                    $('#appendPaypalModal').append(data.html);
                    $('.DataTableID').DataTable();
                    $('#paypalModal').modal('show');
                }else{
                    Swal.fire({
                        type: data.result,
                        title: data.title,
                        text: data.message,
                    });
                }
            },
        });
    });
    $(document).on('click','.cancelSub',function(e){
        e.preventDefault();
        Swal.fire({
            type: 'warning',
            title: 'Request for Cancellation?',
            showCancelButton: true,
            text: 'are you sure you want to cancel your current subscription?',
        }).then(function (result) {
                if(result.value){
                    $.ajax({
                        type: "post",
                        url: "{{route('request.cancel.subscription')}}",
                    success: function (response) {
                        if(response.response == 'success'){
                            Swal.fire({
                                type: 'success',
                                title: 'Cancel Request Sent',
                                text: 'The admin is reviewing your request.',
                            }).then(function (result) {
                                location.reload();
                            });
                        }else if(response.response == 'warning'){
                            Swal.fire({
                                type: 'warning',
                                title: 'Request Already Sent',
                                text: 'Please Wait, The admin is reviewing your request.',
                            });
                        }else{
                            Swal.fire({
                                type: 'error',
                                title: 'Oops...',
                                text: 'Something went wrong!',
                            });
                        }
                    },
                });
            }
        });
    });
    $(document).on('click', '.statBtn', function(e) {
        e.preventDefault();
        $('.statBtn').removeClass('active');
        $(this).addClass('active');
        console.log($(this).hasClass('clicks'));
        if($(this).hasClass('clicks')){
            $('.tableHolder').css('display','none');
            $('.clicksTable').css('display','block');
        }else if($(this).hasClass('views')){
            $('.tableHolder').css('display','none');
            $('.viewsTable').css('display','block');
        }else{
            $('.tableHolder').css('display','none');
            $('.subscTable').css('display','block');
        }
    });
    $(document).on('click', '.next-5', function(e) {
        e.preventDefault();
        $('#2a').submit();
    });
    $(document).on('submit', '#1a', function(e) {
        e.preventDefault();
        var formData = new FormData(this);
        var placeholderID = [];
        var phFormat = [];
        var phName = [];
        $('[name=placeholder_name]').each(function (index, element) {
            phName.push($(element).val());
        });
        $('[name=placeholder_format]').each(function (index, element) {
            phFormat.push($(element).val());

        });
        $('[name=newT_placeholder_id]').each(function (index, element) {
            placeholderID.push($(element).val());
        });
        $('[name=newT_placeholder_ids]').val(placeholderID);
        $('[name=ntPlaceholder_names]').val(phName);
        $('[name=ntPlaceholder_formats]').val(phFormat);
        $('[name=newT_url]').val($('[name=templateTag]').val());
        var formData = new FormData(this);
        $.ajax({
            type: "post",
            url: "{{route('pageTemplate.save')}}",
            data: formData,
            dataType: "json",
            processData: false,
            contentType: false,
            success: function (response) {
                console.log(response.result[0]['result']);
                if(response.result[0]['result'] == 'success'){
                    Swal.fire({
                        type: response.result[0]['type'],
                        title: response.result[0]['title'],
                        text: response.result[0]['message'],
                    });
                    $('.hideOnscs').hide('slow',function(){
                        $('div#showOnGenerate').slideDown('fast');
                        $('.urlHere').val(response.PageURL);
                        $('.pageURLview').attr('href', response.PageURL);
                    });
                }else{
                    Swal.fire({
                        type: response.result[0]['type'],
                        title: response.result[0]['title'],
                        text: response.result[0]['message'],
                    });
                }
            },
            error: function (errors) {
                $.each(errors.responseJSON.errors, function (indexInArray, valueOfElement) {
                    Swal.fire({
                        type: 'error',
                        title: 'error',
                        text: valueOfElement[0],
                    });
                });
            }
        });
    });
    $(document).on('submit', '#2a', function(e) {
        e.preventDefault();
        var socialProvider = [];
        var formData = new FormData(this);
        $('[name=social_provider]').each(function (index, element) {
            socialProvider.push($(element).val());
        });
        formData.append('social_provider', socialProvider);
        $('input, textarea').removeClass('is-invalid');
        $('.upload-pic .profile, #template, #socials').removeClass('error');
        $.ajax({
            type: "post",
            url: "{{route('profile.save')}}",
            data: formData,
            dataType: "json",
            processData: false,
            contentType: false,
            success: function (response) {
                if(response.result == 'success'){
                    Swal.fire({
                        type: 'success',
                        title: 'Good Job!',
                        text: 'Profile page have been successfully updated.',
                    }).then(function (result) {
                        if (result.value) {
                            location.reload();
                        }
                    });
                }else{
                    Swal.fire({
                        type: 'error',
                        title: 'Oops...',
                        text: 'Something went wrong!',
                    });
                }
            },
            beforeSend: function (response) {
                $('#loadingDiv').show();
            },
            complete: function (response) {
                $('#loadingDiv').fadeOut('fast');
            },
            error: function (errors) {
                $.each(errors.responseJSON.errors, function (indexInArray, valueOfElement) {
                    if(indexInArray == 'image'){
                        $('.upload-pic .profile').addClass('error');
                    }else if(indexInArray == 'template'){
                        $('#template').addClass('error');
                    }else if(indexInArray == 'social_url' || indexInArray == 'social_provider'){
                        $('#socials').addClass('error');
                        $('#socials').find('strong').text(valueOfElement[0]);
                    }else{
                        $(`[name^=${indexInArray}]`).addClass('is-invalid');
                        $(`[name^=${indexInArray}]`).next().find('strong').text(valueOfElement[0]);
                    }
                });
            }
        });
    });
    $(document).on('click', '.saveGen', function (e) {
        e.preventDefault();
        $('#1a').submit();
    });
    $(document).on('click', '.saveBtn', function () {
        var placeholderID = [];
        var phFormat = [];
        var phName = [];
        $('[name=placeholder_id]').each(function (index, element) {
            placeholderID.push($(element).val());
        });
        $('[name=placeholder_name]').each(function (index, element) {
            phName.push($(element).val());
        });
        $('[name=placeholder_format]').each(function (index, element) {
            phFormat.push($(element).val());

        });
        $('[name=placeholder_ids]').val(placeholderID);
        $('[name=placeholder_names]').val(phName);
        $('[name=placeholder_formats]').val(phFormat);
        var formData = $('#placeholder-form, #other-placeholder-form').serialize();
        $.ajax({
            type: "post",
            url: "{{route('profile.save-placeholder')}}",
            data: formData,
            dataType: "json",
            success: function (response) {
                if(response.result == 'success'){
                    Swal.fire({
                        type: 'success',
                        title: 'Good Job!',
                        text: 'Profile page have been successfully updated.',
                    }).then(function (result) {
                        if (result.value) {
                            location.reload();
                        }
                    });
                }else{
                    Swal.fire({
                        type: 'error',
                        title: 'Oops...',
                        text: 'Something went wrong!',
                    });
                }
            },
            // error: function (errors) {
            //     $.each(errors.responseJSON.errors, function (indexInArray, valueOfElement) {
            //         $(`[name^=${indexInArray}]`).addClass('is-invalid');
            //         $(`[name^=${indexInArray}]`).next('strong').text(valueOfElement[0]);
            //     });
            // }
        });
    });
    $(document).on('click', '.btn-placeholder', function () {
        if($(this).find('i').hasClass('fa-plus')){
            parent = $(this).parents('form');
            if(parent.attr('id') == "placeholder-form"){
                if($("[name=placeholder_id]").last().find('option').length - 1){
                    var selectOptions = '';
                    $("[name=placeholder_id]").last().find('option').each(function(index, element) {
                        if($('[name=placeholder_id]').last().val() != $(element).val()){
                            selectOptions += `<option value="${$(element).val()}">${$(element).text()}</option>`;
                        }
                    });
                    $(parent).append(`<div class="form-inline justify-content-center">
                                        <select class="form-control" name="placeholder_id">
                                            ${selectOptions}
                                        </select>
                                        <input class="form-control" type="text" name="placeholder_value[]" placeholder="Type Here">
                                        <a class="form-control btn-placeholder"><i class="fa fa-minus"></i></a>
                                        <a class="form-control btn-placeholder"><i class="fa fa-plus"></i></a>
                                    </div>`);
                    $(this).siblings('select').attr('disabled', 'disabled');
                    if($(this).parent().find('.fa-minus').length){
                        $(this).remove();
                    }else{
                        $(this).find('i').removeClass('fa-plus').addClass('fa-minus');
                    }
                }else{
                    alert('No more placeholder available.');
                    $(this).siblings('select').attr('disabled', 'disabled');
                    if($(this).parent().find('.fa-minus').length){
                        $(this).remove();
                    }else{
                        $(this).find('i').removeClass('fa-plus').addClass('fa-minus');
                    }
                }
            }else{
                $('#appendHere').append(`<div class="form-inline justify-content-center">
                                    <input class="form-control" type="text" name="placeholder_name" placeholder="Name of the Placeholder">
                                    <input class="form-control" type="text" name="placeholder_format" placeholder="%Example%">
                                    <a class="form-control btn-placeholder"><i class="fa fa-minus"></i></a>
                                    <a class="form-control btn-placeholder"><i class="fa fa-plus"></i></a>
                                </div>`);
                if($(this).parent().find('.fa-minus').length){
                    $(this).remove();
                }else{
                    $(this).find('i').removeClass('fa-plus').addClass('fa-minus');
                }
            }
        }else{
            parent = $(this).parents('form');
            if(parent.attr('id') == "placeholder-form"){
                var selectedOption = $(this).siblings('select');
                $("[name=placeholder_id]").last().append(`<option value="${selectedOption.val()}">${selectedOption.find('option:selected').text()}</option>`);
                $(this).parents('.form-inline').remove();
                $("[name=placeholder_id]").last().removeAttr('disabled');
                if(parent.find('.btn-placeholder').last().parent().find('.btn-placeholder').length == 1){
                    parent.find('.btn-placeholder').last().parent().append(`<a class="form-control btn-placeholder"><i class="fa fa-plus"></i></a>`);
                }

                if($("[name=placeholder_id]").length == 1){
                    parent.find('.btn-placeholder').last().parent().find('.btn-placeholder i.fa-minus').parent().remove();
                }
            }else{
                $(this).parents('.form-inline').remove();
                if($('#appendHere').find('.btn-placeholder').last().parent().find('.btn-placeholder').length == 1){
                    $('#appendHere').find('.btn-placeholder').last().parent().append(`<a class="form-control btn-placeholder"><i class="fa fa-plus"></i></a>`);
                }

                if($("[name^=placeholder_name]").length == 1){
                    $('#appendHere').find('.btn-placeholder').last().parent().find('.btn-placeholder i.fa-minus').parent().remove();
                }
            }
        }
    });
    $(document).on('click', '.btn-ntplaceholder', function () {
        if($(this).find('i').hasClass('fa-plus')){
            parent = $(this).parents('div.pholderForm');
            if(parent.attr('id') == "f1"){
                if($("[name=newT_placeholder_id]").last().find('option').length - 1){
                    var selectOptions = '';
                    $("[name=newT_placeholder_id]").last().find('option').each(function(index, element) {
                        if($('[name=newT_placeholder_id]').last().val() != $(element).val()){
                            selectOptions += `<option value="${$(element).val()}">${$(element).text()}</option>`;
                        }
                    });
                    $('.GenerateForm .appendGenerateHere').append(`<div class="form-inline justify-content-center">
                                        <select class="form-control" name="newT_placeholder_id">
                                            ${selectOptions}
                                        </select>
                                        <input class="form-control" type="text" name="newT_placeholder_value[]" placeholder="Type Here">
                                        <a class="form-control btn-ntplaceholder"><i class="fa fa-minus"></i></a>
                                        <a class="form-control btn-ntplaceholder"><i class="fa fa-plus"></i></a>
                                    </div>`);
                    $(this).siblings('select').attr('disabled', 'disabled');
                    if($(this).parent().find('.fa-minus').length){
                        $(this).remove();
                    }else{
                        $(this).find('i').removeClass('fa-plus').addClass('fa-minus');
                    }
                }else{
                    alert('No more placeholder available.');
                    $(this).siblings('select').attr('disabled', 'disabled');
                    if($(this).parent().find('.fa-minus').length){
                        $(this).remove();
                    }else{
                        $(this).find('i').removeClass('fa-plus').addClass('fa-minus');
                    }
                }
            }else{
                $('.GenerateForm .appendOtherPh').append(`<div class="form-inline justify-content-center">
                                    <input class="form-control" type="text" name="ntPlaceholder_name" placeholder="Name of the Placeholder">
                                    <input class="form-control" type="text" name="ntPlaceholder_format" placeholder="%Example%">
                                    <a class="form-control btn-ntplaceholder"><i class="fa fa-minus"></i></a>
                                    <a class="form-control btn-ntplaceholder"><i class="fa fa-plus"></i></a>
                                </div>`);
                if($(this).parent().find('.fa-minus').length){
                    $(this).remove();
                }else{
                    $(this).find('i').removeClass('fa-plus').addClass('fa-minus');
                }
            }
        }else{
            parent = $(this).parents('div.pholderForm');
            if(parent.attr('id') == "f1"){
                var selectedOption = $(this).siblings('select');
                $("[name=newT_placeholder_id]").last().append(`<option value="${selectedOption.val()}">${selectedOption.find('option:selected').text()}</option>`);
                $(this).parents('.form-inline').remove();
                $("[name=newT_placeholder_id]").last().removeAttr('disabled');
                if(parent.find('.btn-ntplaceholder').last().parent().find('.btn-ntplaceholder').length == 1){
                    parent.find('.btn-ntplaceholder').last().parent().append(`<a class="form-control btn-ntplaceholder"><i class="fa fa-plus"></i></a>`);
                }
                if($("[name=newT_placeholder_id]").length == 1){
                    parent.find('.btn-ntplaceholder').last().parent().find('.btn-ntplaceholder i.fa-minus').parent().remove();
                }
            }else{
                $(this).parents('.form-inline').remove();
                if($('.GenerateForm .appendOtherPh').find('.btn-ntplaceholder').last().parent().find('.btn-ntplaceholder').length == 1){
                    $('.GenerateForm .appendOtherPh').find('.btn-ntplaceholder').last().parent().append(`<a class="form-control btn-ntplaceholder"><i class="fa fa-plus"></i></a>`);
                }
                if($("[name=ntPlaceholder_name]").length == 1){
                    $('.GenerateForm .appendOtherPh').find('.btn-ntplaceholder').last().parent().find('.btn-ntplaceholder i.fa-minus').parent().remove();
                }
            }
        }
    });
    $(document).on('keyup', '[name=profile_url]', function() {
        clearTimeout(timer);
        elem = $(this);
        timer = setTimeout(function() {
            if(elem.val()){
                $('.CopyBtnHolder').show();
            }else{
                $('.CopyBtnHolder').hide();
            }
        }, 700);
    });
    $(document).on('change', '[name=custom_placeholder]', function () {
        console.log($(this).is(':checked'));
        if($(this).is(':checked')){
            $('.GenerateForm .pholderForm').last().slideDown(500, function(){
                $('html, body').animate({
                    scrollTop: $('.GenerateForm .pholderForm').last().offset().top - $('header').outerHeight()
                }, 500);
            });
        }else{
            $('.GenerateForm .pholderForm').last().slideUp();
        }
    });
    $(document).on('click', '#btn-custom-placeholder', function () {
        setTimeout(function(){
            if($('[name=custom_placeholder]').is(':checked')){
                $('.phForm').last().slideDown(500, function(){
                    $('html, body').animate({
                        scrollTop: $('.phForm').last().offset().top - $('header').outerHeight()
                    }, 500);
                });
            }else{
                $('.phForm').last().slideUp();
            }
        }, 200);
    });
    $(document).on('click', '.item-theme', function () {
        $('.item-theme').removeClass('active');
        $(this).addClass('active');
        $(this).find('[name=template]').prop('checked', true);
    });
    $(document).on('click', '.switch', function (e) {
        if($(this).hasClass('pro')){
            e.preventDefault();
        }
    });
    $(document).on('click', '#btnCopy', function (e) {
        e.preventDefault();
        var urlInput = $(this).parents('.profile-form').find('[name=profile_url]');
        var textToCopy = urlInput.data('domain')+'/'+urlInput.val();
        copyToClipboard(textToCopy);
        $(this).text('Copied');
    });
    $(document).on('click','.pageURLcopy',function(e){
        e.preventDefault();
        text = $('.urlHere').val();
        copyToClipboard(text);
        $(this).text('Copied');
    });
    $(document).on('click','.copyOnTable',function(e){
        e.preventDefault();
        var text = $(this).data('url');
        var textToCopy = location.host+'/'+text;
        copyToClipboard(textToCopy);
        $(this).text('copied');
    });
    $(document).on('click', '.btn-remadd', function () {
        if ($(this).text() == '+') {
            if($("[name=social_provider]").last().find('option').length - 1){
                var selectOptions;
                $("[name=social_provider]").last().find('option').each(function(index, element) {
                    if($('[name=social_provider]').last().val() != $(element).val()){
                        selectOptions += `<option value="${$(element).val()}">${$(element).val()}</option>`;
                    }
                });
                $('#appendSocial').append(`<div class="form-inline">
                                                <select name="social_provider" class="form-control">
                                                    ${selectOptions}
                                                </select>
                                                <input type="text" class="form-control fullname" placeholder="example.com" name="social_url[]">
                                                <a class="btn-remadd fc">-</a>
                                                <a class="btn-remadd">+</a>
                                            </div>`);
                $(this).siblings('select').attr('disabled', 'disabled');
                if($(this).siblings('.fc').length){
                    $(this).remove();
                }else{
                    $(this).text('-').addClass('fc');
                }
            }else{
                alert('No more social media platform.');
                $(this).siblings('select').attr('disabled', 'disabled');
                if($(this).siblings('.fc').length){
                    $(this).remove();
                }else{
                    $(this).text('-').addClass('fc');
                }
            }
        }else{
            var selectedOption = $(this).siblings('select').val();
            $("[name=social_provider]").last().append(`<option value="${selectedOption}">${selectedOption}</option>`);
            $(this).parents('.form-inline').remove();
            $("[name=social_provider]").last().removeAttr('disabled');
            if($('.btn-remadd').last().parent().find('.btn-remadd').length == 1){
                $('.btn-remadd').last().parent().append(`<a class="btn-remadd">+</a>`);
            }
            if($("[name=social_provider]").length == 1){
                $('a.fc').last().remove();
            }
        }
    });
    $(document).on('click','.oneAfback2', function(e){
        e.preventDefault();
        $('#1a .editTemplateTab').empty();
        $('#1a .editTemplateTab').css('display', 'none');
        $('#1a .firstPage').css('display','block');
    });
    $(document).on('click','.oneAsback', function(e){
        e.preventDefault();
        location.reload();
    });
    $(document).on('click','.deleteGen', function(e){
        e.preventDefault();
        $id = $(this).data('genid');
        Swal.fire({
            type: 'warning',
            title: 'Delete This URL?',
            showCancelButton: true,
            text: 'This URL will be gone forever?',
        }).then(function (result) {
            if(result.value){
                $.ajax({
                    type: "post",
                    url: "{{route('pageTemplate.deleteGenPage')}}",
                    data: {id : $id},
                    success: function (data) {
                        if(data.result == 'success'){
                            Swal.fire({
                                type: 'success',
                                title: 'Good Job!',
                                text: 'The URL has been deleted',
                            }).then(function (result) {
                                location.reload();
                            });
                        }else{
                            Swal.fire({
                                type: 'error',
                                title: 'Oops...',
                                text: 'Something went wrong!',
                            });
                        }
                    },
                });
            }
        });
    });
    $(document).on('click','.deletePageTemplate', function(e){
        e.preventDefault();
        $id = $(this).data('id');
        Swal.fire({
            type: 'warning',
            title: 'Delete This Page?',
            showCancelButton: true,
            text: 'All URLs and its Statistics will also be deleted!',
        }).then(function (result) {
            if(result.value){
                $.ajax({
                    type: "post",
                    url: "{{route('pageTemplate.deletePage')}}",
                    data: {id : $id},
                    success: function (data) {
                        if(data.result == 'success'){
                            Swal.fire({
                                type: 'success',
                                title: 'Good Job!',
                                text: 'The page has been deleted',
                            }).then(function (result) {
                                location.reload();
                            });
                        }else{
                            Swal.fire({
                                type: 'error',
                                title: 'Oops...',
                                text: 'Something went wrong!',
                            });
                        }
                    },
                });
            }
        });
    });
    $(document).on('click','.oneAfback', function(e){
        e.preventDefault();
        if($(this).data('page') == 2){
            location.reload();
        }else if($(this).data('page') == 3){
            $(this).parents('.oneApages').css('display', 'none');
            $('#1a .secondPage').css('display','block');
        }else if($(this).data('page') == 4){
            $(this).parents('.oneApages').css('display', 'none');
            $('#1a .thirdPage').css('display','block');
        }else{
        }
    });
    $(document).on('click','.pagesStep', function(e){
        e.preventDefault();
        $input1 = $('.secondPage [name="templateName"]').val();
        $input2 = $('.secondPage [name="templateTag"]').val();
        $input3 = $('.secondPage [name="fullName"]').val();
        id = $(this).data('pageid');
        urlid = $(this).data('urlid');
        generate = $(this).data('generate');
        pageid = $('[name=pageTemplateid]').val();
        step = $(this).data('step');
            $.ajax({
                type: "get",
                url: "{{route('pageTemplate.getForm')}}",
                data: {id : id, step:step, pageid : pageid, generate:generate, urlid:urlid},
                success: function (data) {
                    console.log(data.step);
                    if(data.step == 1 ){
                        $('#1a .oneApages').css('display', 'none');
                        $("#1a .secondPage").empty();
                        $('#1a .secondPage').append(data.html);
                        $('#1a .secondPage').css('display','block');
                        CKEDITOR.replaceAll('editEditor');
                    }else if((data.step == 2) && ($input1!='' && $input2!='' && $input3!='') || ((data.generate == true) && (data.step == 2))){
                        $('#1a .oneApages').css('display', 'none');
                        $("#1a .thirdPage").empty();
                        $('#1a .thirdPage').append(data.html);
                        $('#1a .thirdPage').css('display','block');
                    }else{
                        Swal.fire({
                            type: 'error',
                            title: 'Some fields are blank',
                            text: 'Please fill up all the blank fields.',
                        });
                    }
                },
            });
    });
    $(document).on('click','.saveNext2',function(e) {
        e.preventDefault();
        $input1 = $('.secondPage [name="upTemplateName"]').val();
        $input2 = $('.secondPage [name="upTemplateTag"]').val();
        $input3 = $('.secondPage [name="upFullName"]').val();
        if($input1!='' && $input2!='' && $input3!=''){;
        }else{
            Swal.fire({
                type: 'error',
                title: 'Some fields are blank',
                text: 'Please fill up all the blank fields.',
            }).then(function (result) {
                if (result.value) {
                }
            });
        }
    });
    $(document).on('click','.statsView', function(e){
        e.preventDefault();
        id = $(this).data('pageid');
        $.ajax({
            type: "get",
            url: "{{route('pageTemplate.getStatsModal')}}",
            data: {pageid : id},
            success: function (data) {
                if(data.result == 'success'){
                    $("#appendUrlModal").empty();
                    $('#appendUrlModal').append(data.html);
                    $('.DataTableID').DataTable();
                    $('#statsModal').modal('show');
                }else{
                    Swal.fire({
                        type: data.result,
                        title: data.title,
                        text: data.message,
                    });
                }
            },
        });
    });
    $("[name=image]").change(function () {
        readURL(this);
    });
    function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $('#imageUpload').attr('src', e.target.result);
            }

            reader.readAsDataURL(input.files[0]);
        }
    }
    function copyToClipboard(text) {
        var $temp = $("<input>");
        $("body").append($temp);
        toInput = $temp.val(text).select();
        document.execCommand("copy");
        $temp.remove();
    }
</script>
@stop
