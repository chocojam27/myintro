<li class="nav-item active">
    <a class='sidebar-link' href="{{ route(ADMIN . '.content-management.index') }}">
        <span class="icon-holder">
            <i class="c-purple-500 ti-layout"></i>
        </span>
        <span class="title">Content Management</span>
    </a>
</li>
<li class="nav-item active">
    <a class='sidebar-link' href="{{ route(ADMIN . '.stats.index') }}">
        <span class="icon-holder">
            <i class="c-purple-500 ti-stats-up"></i>
        </span>
        <span class="title">Statistics</span>
    </a>
</li>
<li class="nav-item active">
    <a class='sidebar-link' href="{{ route(ADMIN . '.subscriptions') }}">
        <span class="icon-holder">
            <i class="c-purple-500 ti-id-badge"></i>
        </span>
        <span class="title">Subscriptions</span>
    </a>
</li>
<li class="nav-item active">
    <a class='sidebar-link' href="{{ route(ADMIN . '.placeholders.index') }}">
        <span class="icon-holder">
            <i class="c-purple-500 ti-write"></i>
        </span>
        <span class="title">Placeholders</span>
    </a>
</li>
<li class="nav-item active">
    <a class='sidebar-link' href="{{ route(ADMIN . '.users.index') }}">
        <span class="icon-holder">
            <i class="c-purple-500 ti-user"></i>
        </span>
        <span class="title">Users</span>
    </a>
</li>
