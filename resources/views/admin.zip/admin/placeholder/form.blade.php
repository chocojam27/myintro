<div class="row mB-40">
	<div class="col-sm-8">
		<div class="bgc-white p-20 bd">
			{!! Form::myInput('text', 'format', 'Format') !!}

            {!! Form::myInput('text', 'description', 'Description') !!}
		</div>
	</div>
</div>
